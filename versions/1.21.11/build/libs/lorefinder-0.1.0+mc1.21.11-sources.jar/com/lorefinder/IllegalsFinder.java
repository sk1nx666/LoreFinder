package com.lorefinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Queue;
import java.util.Set;

public class IllegalsFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgChecks = settings.createGroup("Checks");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> scanRadius = sgGeneral.add(new IntSetting.Builder()
        .name("scan-radius")
        .description("Chunk radius to scan (smaller = much better FPS). Not the same as render distance.")
        .defaultValue(4)
        .range(1, 16)
        .sliderRange(2, 8)
        .build()
    );

    private final Setting<Integer> chunksPerTick = sgGeneral.add(new IntSetting.Builder()
        .name("chunks-per-tick")
        .description("How many chunks to scan per tick. Keep at 1–2 on join / low-end PCs.")
        .defaultValue(1)
        .range(1, 8)
        .sliderMax(4)
        .build()
    );

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("rescan-interval")
        .description("Re-queue all chunks in range every N ticks (0 = only scan new chunks).")
        .defaultValue(400)
        .range(0, 2400)
        .sliderRange(100, 1200)
        .build()
    );

    private final Setting<Integer> maxMarkers = sgGeneral.add(new IntSetting.Builder()
        .name("max-markers")
        .description("Maximum illegal blocks to track at once.")
        .defaultValue(256)
        .range(32, 4096)
        .sliderRange(64, 512)
        .build()
    );

    private final Setting<Boolean> invalidPlacement = sgChecks.add(new BoolSetting.Builder()
        .name("invalid-placement")
        .description("Blocks that cannot be placed on their support (e.g. flowers on gravel, saplings on stone).")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> floatingLava = sgChecks.add(new BoolSetting.Builder()
        .name("floating-lava")
        .description("Lava with no solid block beneath.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> floatingWater = sgChecks.add(new BoolSetting.Builder()
        .name("floating-water")
        .description("Water source blocks with no solid block beneath.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Boolean> orphanBeds = sgChecks.add(new BoolSetting.Builder()
        .name("orphan-beds")
        .description("Bed halves missing their partner.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> orphanDoubleBlocks = sgChecks.add(new BoolSetting.Builder()
        .name("orphan-double-blocks")
        .description("Tall plants missing their upper or lower half.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> floatingAttached = sgChecks.add(new BoolSetting.Builder()
        .name("floating-attached")
        .description("Torches, ladders, levers, buttons, lanterns, etc. without valid support.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How boxes are drawn.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity for boxes.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines)
        .defaultValue(35)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("Fill color.")
        .defaultValue(new SettingColor(220, 70, 70, 35))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Outline color.")
        .defaultValue(new SettingColor(255, 100, 100, 255))
        .build()
    );

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draw tracers to illegal blocks.")
        .defaultValue(false)
        .build()
    );

    private final Set<class_2338> markers = new HashSet<>();
    private final Queue<class_1923> scanQueue = new ArrayDeque<>();
    private final Set<class_1923> queued = new HashSet<>();
    private int rescanTimer;
    private double maxDistSq;

    public IllegalsFinder() {
        super(LoreFinderAddon.CATEGORY, "illegals-finder", "ESP for illegal block states and placements in render distance.");
    }

    @Override
    public void onActivate() {
        markers.clear();
        scanQueue.clear();
        queued.clear();
        rescanTimer = 0;
        updateMaxDistSq();
        queueChunksInRange();
    }

    @Override
    public void onDeactivate() {
        markers.clear();
        scanQueue.clear();
        queued.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate() || mc.field_1724 == null) return;

        updateMaxDistSq();

        pruneMarkers();

        int budget = chunksPerTick.get();
        while (budget-- > 0 && !scanQueue.isEmpty()) {
            class_1923 chunkPos = scanQueue.poll();
            queued.remove(chunkPos);

            if (!IllegalBlockChecks.isChunkBorderContextLoaded(mc.field_1687, chunkPos)) {
                enqueueChunk(chunkPos);
                continue;
            }

            class_2818 chunk = mc.field_1687.method_8497(chunkPos.field_9181, chunkPos.field_9180);
            if (chunk == null || chunk.method_12223()) continue;

            scanChunk(chunk);
            if (markers.size() >= maxMarkers.get()) {
                scanQueue.clear();
                queued.clear();
                break;
            }
        }

        if (scanInterval.get() > 0 && ++rescanTimer >= scanInterval.get()) {
            rescanTimer = 0;
            queueChunksInRange();
        }
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!Utils.canUpdate()) return;
        enqueueChunk(event.chunk().method_12004());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!Utils.canUpdate() || markers.isEmpty()) return;

        SettingColor side = new SettingColor(sideColor.get());
        side.a = fillOpacity.get();
        SettingColor line = lineColor.get();

        Iterator<class_2338> it = markers.iterator();
        while (it.hasNext()) {
            class_2338 pos = it.next();
            class_2680 state = mc.field_1687.method_8320(pos);

            if (!isIllegalAt(pos, state)) {
                it.remove();
                continue;
            }

            if (tracers.get()) {
                event.renderer.line(
                    RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    line
                );
            }

            RenderUtils.renderTickingBlock(pos, side, line, shapeMode.get(), 0, 8, true, false);
        }
    }

    @Override
    public String getInfoString() {
        if (!scanQueue.isEmpty()) return markers.size() + "+" + scanQueue.size();
        return Integer.toString(markers.size());
    }

    private void updateMaxDistSq() {
        int radius = scanRadius.get() * 16;
        maxDistSq = radius * radius;
    }

    private void queueChunksInRange() {
        if (mc.field_1724 == null) return;

        class_1923 playerChunk = mc.field_1724.method_31476();
        int radius = scanRadius.get();

        for (int cx = playerChunk.field_9181 - radius; cx <= playerChunk.field_9181 + radius; cx++) {
            for (int cz = playerChunk.field_9180 - radius; cz <= playerChunk.field_9180 + radius; cz++) {
                enqueueChunk(new class_1923(cx, cz));
            }
        }
    }

    private void enqueueChunk(class_1923 chunkPos) {
        if (mc.field_1724 == null) return;

        int dx = Math.abs(chunkPos.field_9181 - mc.field_1724.method_31476().field_9181);
        int dz = Math.abs(chunkPos.field_9180 - mc.field_1724.method_31476().field_9180);
        if (dx > scanRadius.get() || dz > scanRadius.get()) return;

        if (queued.add(chunkPos)) {
            scanQueue.offer(chunkPos);
        }
    }

    private void pruneMarkers() {
        Iterator<class_2338> it = markers.iterator();
        while (it.hasNext()) {
            class_2338 pos = it.next();
            class_2680 state = mc.field_1687.method_8320(pos);

            if (state.method_26215()) {
                it.remove();
                continue;
            }

            if (PlayerUtils.squaredDistanceTo(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > maxDistSq) {
                it.remove();
                continue;
            }

            if (!isIllegalAt(pos, state)) it.remove();
        }
    }

    private void scanChunk(class_2818 chunk) {
        if (!Utils.canUpdate() || markers.size() >= maxMarkers.get()) return;

        class_1923 chunkPos = chunk.method_12004();
        int baseX = chunkPos.method_8326();
        int baseZ = chunkPos.method_8328();

        boolean checkInvalid = invalidPlacement.get();
        boolean checkLava = floatingLava.get();
        boolean checkWater = floatingWater.get();
        boolean checkBeds = orphanBeds.get();
        boolean checkDouble = orphanDoubleBlocks.get();
        boolean checkAttached = floatingAttached.get();

        class_2826[] sections = chunk.method_12006();

        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            class_2826 section = sections[sectionIndex];
            if (!IllegalBlockChecks.sectionMightContainIllegal(
                section, checkInvalid, checkLava, checkWater, checkBeds, checkDouble, checkAttached
            )) {
                continue;
            }

            int sectionBottom = chunk.method_31604(sectionIndex);

            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (markers.size() >= maxMarkers.get()) return;

                        class_2680 sectionState = section.method_12254(x, y, z);
                        if (sectionState.method_26215()) continue;

                        int wx = baseX + x;
                        int wy = sectionBottom + y;
                        int wz = baseZ + z;

                        double distSq = PlayerUtils.squaredDistanceTo(wx + 0.5, wy + 0.5, wz + 0.5);
                        if (distSq > maxDistSq) continue;

                        class_2338 pos = new class_2338(wx, wy, wz);
                        if (!IllegalBlockChecks.isContextLoaded(mc.field_1687, pos)) continue;

                        class_2680 state = mc.field_1687.method_8320(pos);
                        if (state.method_26215() || state.method_26204() != sectionState.method_26204()) continue;

                        if (isIllegalAt(pos, state)) {
                            markers.add(pos.method_10062());
                        }
                    }
                }
            }
        }
    }

    private boolean isIllegalAt(class_2338 pos, class_2680 state) {
        return IllegalBlockChecks.isIllegal(
            mc.field_1687,
            pos,
            state,
            invalidPlacement.get(),
            floatingLava.get(),
            floatingWater.get(),
            orphanBeds.get(),
            orphanDoubleBlocks.get(),
            floatingAttached.get()
        );
    }
}
