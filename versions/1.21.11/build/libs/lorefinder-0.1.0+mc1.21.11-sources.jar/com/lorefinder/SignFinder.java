package com.lorefinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2625;
import net.minecraft.class_2818;
import net.minecraft.class_8242;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SignFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgOldSign = settings.createGroup("Old Sign Finder");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("How often to rescan signs in loaded chunks, in ticks.")
        .defaultValue(10)
        .min(1)
        .sliderMax(100)
        .build()
    );

    private final Setting<Boolean> oldSignFinder = sgOldSign.add(new BoolSetting.Builder()
        .name("old-sign-finder")
        .description("Only highlight signs whose text contains dates matching the year filter.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> yearThreshold = sgOldSign.add(new IntSetting.Builder()
        .name("year-threshold")
        .description("Reference year for comparisons (2010–current year; e.g. 2025 + Any before = signs with a year before 2025).")
        .defaultValue(2025)
        .range(SignYearParser.MIN_YEAR, 2100)
        .sliderRange(SignYearParser.MIN_YEAR, SignYearParser.maxYear())
        .visible(oldSignFinder::get)
        .build()
    );

    private final Setting<SignYearParser.CompareMode> compareMode = sgOldSign.add(new EnumSetting.Builder<SignYearParser.CompareMode>()
        .name("compare-mode")
        .description("How parsed years are compared to the threshold.")
        .defaultValue(SignYearParser.CompareMode.AnyBefore)
        .visible(oldSignFinder::get)
        .build()
    );

    private final Setting<Boolean> includeNoYear = sgOldSign.add(new BoolSetting.Builder()
        .name("include-no-year")
        .description("Also highlight signs with no detectable year in the text.")
        .defaultValue(false)
        .visible(oldSignFinder::get)
        .build()
    );

    private final Setting<Boolean> bothSides = sgOldSign.add(new BoolSetting.Builder()
        .name("both-sides")
        .description("Read front and back text on waxed signs.")
        .defaultValue(true)
        .visible(oldSignFinder::get)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How boxes are drawn.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity for boxes.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines)
        .defaultValue(40)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("Fill color.")
        .defaultValue(new SettingColor(120, 180, 255, 40))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Outline color.")
        .defaultValue(new SettingColor(120, 180, 255, 255))
        .build()
    );

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draw tracers to matching signs.")
        .defaultValue(false)
        .build()
    );

    private final Set<class_2338> matches = new HashSet<>();
    private int tickTimer;

    public SignFinder() {
        super(LoreFinderAddon.CATEGORY, "sign-finder", "ESP for signs matching Old Sign Finder filters.");
    }

    @Override
    public void onActivate() {
        matches.clear();
        tickTimer = scanInterval.get();
        clampYearThreshold();
        scan();
    }

    private void clampYearThreshold() {
        int max = SignYearParser.maxYear();
        int value = yearThreshold.get();
        if (value > max) yearThreshold.set(max);
        if (value < SignYearParser.MIN_YEAR) yearThreshold.set(SignYearParser.MIN_YEAR);
    }

    private int effectiveThreshold() {
        return Math.min(Math.max(yearThreshold.get(), SignYearParser.MIN_YEAR), SignYearParser.maxYear());
    }

    @Override
    public void onDeactivate() {
        matches.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        if (++tickTimer < scanInterval.get()) return;
        tickTimer = 0;
        scan();
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        scanChunk(event.chunk());
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!Utils.canUpdate() || matches.isEmpty()) return;

        SettingColor side = new SettingColor(sideColor.get());
        side.a = fillOpacity.get();
        SettingColor line = lineColor.get();

        for (class_2338 pos : new HashSet<>(matches)) {
            if (tracers.get()) {
                event.renderer.line(
                    RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    line
                );
            }

            RenderUtils.renderTickingBlock(pos, side, line, shapeMode.get(), 0, 8, true, false);
        }
    }

    @Override
    public String getInfoString() {
        return Integer.toString(matches.size());
    }

    private void scan() {
        if (!Utils.canUpdate()) return;

        Set<class_2338> found = new HashSet<>();
        double maxDistSq = Math.pow(mc.field_1690.method_38521() * 16.0, 2);

        for (class_2586 blockEntity : Utils.blockEntities()) {
            if (!(blockEntity instanceof class_2625 sign)) continue;

            class_2338 pos = sign.method_11016();
            if (PlayerUtils.squaredDistanceTo(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > maxDistSq) {
                continue;
            }

            if (shouldHighlight(sign)) {
                found.add(pos.method_10062());
            }
        }

        matches.clear();
        matches.addAll(found);
    }

    private void scanChunk(class_2818 chunk) {
        if (!Utils.canUpdate()) return;

        double maxDistSq = Math.pow(mc.field_1690.method_38521() * 16.0, 2);

        for (class_2586 blockEntity : chunk.method_12214().values()) {
            if (!(blockEntity instanceof class_2625 sign)) continue;

            class_2338 pos = sign.method_11016();
            if (PlayerUtils.squaredDistanceTo(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > maxDistSq) {
                continue;
            }

            if (shouldHighlight(sign)) mark(pos);
            else unmark(pos);
        }
    }

    private boolean shouldHighlight(class_2625 sign) {
        if (!oldSignFinder.get()) return true;

        List<Integer> years = collectYears(sign);
        if (years.isEmpty()) return includeNoYear.get();

        return SignYearParser.matches(years, effectiveThreshold(), compareMode.get());
    }

    private List<Integer> collectYears(class_2625 sign) {
        List<Integer> years = new ArrayList<>();
        appendYears(years, sign.method_49853());

        if (bothSides.get()) {
            appendYears(years, sign.method_49854());
        }

        return years;
    }

    private void appendYears(List<Integer> years, class_8242 signText) {
        if (signText == null) return;

        for (int line = 0; line < 4; line++) {
            class_2561 message = signText.method_49859(line, false);
            if (message == null) continue;

            years.addAll(SignYearParser.parseYears(message.getString()));
        }
    }

    private void mark(class_2338 pos) {
        matches.add(pos.method_10062());
    }

    private void unmark(class_2338 pos) {
        matches.remove(pos);
        if (pos != null) matches.remove(pos.method_10062());
    }
}
