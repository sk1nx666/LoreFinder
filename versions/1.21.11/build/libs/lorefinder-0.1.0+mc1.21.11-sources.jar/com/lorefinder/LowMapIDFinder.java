package com.lorefinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LowMapIDFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgSources = settings.createGroup("Sources");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> mapIdMax = sgGeneral.add(new IntSetting.Builder()
        .name("map-id-max")
        .description("Highlight maps with an ID strictly below this value.")
        .defaultValue(50000)
        .min(2)
        .sliderRange(100, 200000)
        .build()
    );

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("How often to rescan, in ticks.")
        .defaultValue(20)
        .min(1)
        .sliderMax(100)
        .build()
    );

    private final Setting<Boolean> itemFrames = sgSources.add(new BoolSetting.Builder()
        .name("item-frames")
        .description("Scan item frames and glow item frames.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> groundItems = sgSources.add(new BoolSetting.Builder()
        .name("ground-items")
        .description("Scan dropped filled map items.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> showMapId = sgGeneral.add(new BoolSetting.Builder()
        .name("show-map-id")
        .description("Show map ID in the module info string when one match is selected.")
        .defaultValue(true)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How boxes are drawn.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity for boxes.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines)
        .defaultValue(40)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("Fill color.")
        .defaultValue(new SettingColor(210, 175, 120, 40))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Outline color.")
        .defaultValue(new SettingColor(235, 200, 140, 255))
        .build()
    );

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draw tracers to low map ID targets.")
        .defaultValue(false)
        .build()
    );

    private final Set<Integer> matchIds = new HashSet<>();
    private Integer nearestMapId;
    private int tickTimer;

    public LowMapIDFinder() {
        super(LoreFinderAddon.CATEGORY, "low-map-id-finder", "ESP for filled maps with a low map ID in render distance.");
    }

    @Override
    public void onActivate() {
        matchIds.clear();
        nearestMapId = null;
        tickTimer = scanInterval.get();
        scan();
    }

    @Override
    public void onDeactivate() {
        matchIds.clear();
        nearestMapId = null;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        if (++tickTimer < scanInterval.get()) return;
        tickTimer = 0;
        scan();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!Utils.canUpdate() || matchIds.isEmpty()) return;

        SettingColor side = new SettingColor(sideColor.get());
        side.a = fillOpacity.get();
        SettingColor line = lineColor.get();

        Map<Integer, Integer> frameIndex = itemFrames.get()
            ? MapIdHelper.buildFrameEntityToMapId(mc.field_1687)
            : Collections.emptyMap();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!matchIds.contains(entity.method_5628())) continue;
            if (!stillMatches(entity, frameIndex)) continue;

            double x = entity.method_23317();
            double y = entity.method_23318();
            double z = entity.method_23321();

            if (tracers.get()) {
                event.renderer.line(
                    RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    x, y + entity.method_17682() / 2.0, z,
                    line
                );
            }

            var box = entity.method_5829();
            event.renderer.box(
                box.field_1323, box.field_1322, box.field_1321,
                box.field_1320, box.field_1325, box.field_1324,
                side, line, shapeMode.get(), 0
            );
        }
    }

    @Override
    public String getInfoString() {
        if (showMapId.get() && nearestMapId != null && matchIds.size() == 1) {
            return nearestMapId.toString();
        }
        return Integer.toString(matchIds.size());
    }

    private void scan() {
        if (!Utils.canUpdate()) return;

        matchIds.clear();
        nearestMapId = null;

        double maxDistSq = Math.pow(mc.field_1690.method_38521() * 16.0, 2);
        double nearestDist = Double.MAX_VALUE;
        int threshold = mapIdMax.get();

        Map<Integer, Integer> frameIndex = itemFrames.get()
            ? MapIdHelper.buildFrameEntityToMapId(mc.field_1687)
            : Collections.emptyMap();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!entity.method_5805()) continue;
            if (!isSourceEnabled(entity)) continue;

            class_1533 frame = entity instanceof class_1533 f ? f : null;
            class_1799 stack = getMapStack(entity, frame);
            if (stack == null) continue;

            Integer mapId = MapIdHelper.resolveMapId(stack, frame, mc.field_1687, frameIndex);
            if (mapId == null || !MapIdHelper.isOldMap(mapId, 1, threshold)) continue;

            if (PlayerUtils.squaredDistanceTo(entity) > maxDistSq) continue;

            matchIds.add(entity.method_5628());

            double dist = PlayerUtils.squaredDistanceTo(entity);
            if (dist < nearestDist) {
                nearestDist = dist;
                nearestMapId = mapId;
            }
        }
    }

    private boolean stillMatches(class_1297 entity, Map<Integer, Integer> frameIndex) {
        if (!isSourceEnabled(entity)) return false;

        class_1533 frame = entity instanceof class_1533 f ? f : null;
        class_1799 stack = getMapStack(entity, frame);
        if (stack == null) return false;

        Integer mapId = MapIdHelper.resolveMapId(stack, frame, mc.field_1687, frameIndex);
        return mapId != null && MapIdHelper.isOldMap(mapId, 1, mapIdMax.get());
    }

    private boolean isSourceEnabled(class_1297 entity) {
        if (entity instanceof class_1533) return itemFrames.get();
        if (entity instanceof class_1542) return groundItems.get();
        return false;
    }

    private class_1799 getMapStack(class_1297 entity, class_1533 frame) {
        if (frame != null) {
            class_1799 stack = frame.method_6940();
            if (!stack.method_7960() && stack.method_31574(class_1802.field_8204)) return stack;
            return null;
        }

        if (entity instanceof class_1542 itemEntity) {
            class_1799 stack = itemEntity.method_6983();
            if (!stack.method_7960() && stack.method_31574(class_1802.field_8204)) return stack;
        }

        return null;
    }
}
