package com.lorefinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import java.util.HashSet;
import java.util.Set;

public class NamedEntityFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("How often to rescan entities, in ticks.")
        .defaultValue(10)
        .min(1)
        .sliderMax(100)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How boxes are drawn.")
        .defaultValue(ShapeMode.Both)
        .build()
    );

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity for boxes.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines)
        .defaultValue(40)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("Fill color.")
        .defaultValue(new SettingColor(255, 200, 80, 40))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Outline color.")
        .defaultValue(new SettingColor(255, 200, 80, 255))
        .build()
    );

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draw tracers to named entities.")
        .defaultValue(false)
        .build()
    );

    private final Set<Integer> matchIds = new HashSet<>();
    private int tickTimer;

    public NamedEntityFinder() {
        super(LoreFinderAddon.CATEGORY, "named-entity-finder", "ESP for entities with a custom name in render distance.");
    }

    @Override
    public void onActivate() {
        matchIds.clear();
        tickTimer = scanInterval.get();
        scan();
    }

    @Override
    public void onDeactivate() {
        matchIds.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        if (++tickTimer < scanInterval.get()) return;
        tickTimer = 0;
        scan();
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!Utils.canUpdate() || matchIds.isEmpty()) return;

        SettingColor side = new SettingColor(sideColor.get());
        side.a = fillOpacity.get();
        SettingColor line = lineColor.get();

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!matchIds.contains(entity.method_5628())) continue;
            if (!entity.method_5805() || !entity.method_16914()) continue;

            double x = entity.method_23317();
            double y = entity.method_23318();
            double z = entity.method_23321();

            if (tracers.get()) {
                event.renderer.line(
                    RenderUtils.center.field_1352, RenderUtils.center.field_1351, RenderUtils.center.field_1350,
                    x, y + entity.method_17682() / 2.0, z,
                    line
                );
            }

            var box = entity.method_5829();
            event.renderer.box(
                box.field_1323, box.field_1322, box.field_1321,
                box.field_1320, box.field_1325, box.field_1324,
                side, line, shapeMode.get(), 0
            );
        }
    }

    @Override
    public String getInfoString() {
        return Integer.toString(matchIds.size());
    }

    private void scan() {
        if (!Utils.canUpdate()) return;

        matchIds.clear();
        double maxDistSq = Math.pow(mc.field_1690.method_38521() * 16.0, 2);

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!entity.method_5805() || !entity.method_16914()) continue;
            if (PlayerUtils.squaredDistanceTo(entity) > maxDistSq) continue;

            matchIds.add(entity.method_5628());
        }
    }
}
