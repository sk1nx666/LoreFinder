package com.lorefinder;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AncientBuildsFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<List<class_2248>> blocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks")
        .description("Blocks to look for in each chunk.")
        .defaultValue(
            class_2246.field_9989,
            class_2246.field_10445,
            class_2246.field_10056,
            class_2246.field_10065,
            class_2246.field_10161,
            class_2246.field_10431,
            class_2246.field_10121,
            class_2246.field_10187,
            class_2246.field_10336
        )
        .build()
    );

    private final Setting<Integer> requiredTypes = sgGeneral.add(new IntSetting.Builder()
        .name("required-types")
        .description("How many different blocks from the list must appear in a chunk.")
        .defaultValue(1)
        .min(1)
        .sliderMax(16)
        .build()
    );

    private final Setting<Integer> scanInterval = sgGeneral.add(new IntSetting.Builder()
        .name("scan-interval")
        .description("How often to rescan loaded chunks, in ticks.")
        .defaultValue(40)
        .min(1)
        .sliderMax(200)
        .build()
    );

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
        .name("shape-mode")
        .description("How chunk outlines are drawn.")
        .defaultValue(ShapeMode.Lines)
        .build()
    );

    private final Setting<Integer> fillOpacity = sgRender.add(new IntSetting.Builder()
        .name("fill-opacity")
        .description("Fill opacity for chunk boxes.")
        .visible(() -> shapeMode.get() != ShapeMode.Lines)
        .defaultValue(25)
        .range(0, 255)
        .sliderMax(255)
        .build()
    );

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
        .name("side-color")
        .description("Fill color.")
        .defaultValue(new SettingColor(72, 140, 90, 25))
        .build()
    );

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
        .name("line-color")
        .description("Outline color.")
        .defaultValue(new SettingColor(95, 175, 115, 255))
        .build()
    );

    private final Set<class_1923> matchingChunks = new HashSet<>();
    private int tickTimer;

    public AncientBuildsFinder() {
        super(LoreFinderAddon.CATEGORY, "ancient-builds-finder", "Highlights chunks containing ancient build blocks.");
    }

    @Override
    public void onActivate() {
        matchingChunks.clear();
        tickTimer = scanInterval.get();
        scan();
    }

    @Override
    public void onDeactivate() {
        matchingChunks.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!Utils.canUpdate()) return;

        if (++tickTimer < scanInterval.get()) return;
        tickTimer = 0;
        scan();
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        if (!Utils.canUpdate()) return;

        class_2818 chunk = event.chunk();
        class_1923 pos = chunk.method_12004();

        if (chunkMatches(chunk)) matchingChunks.add(pos);
        else matchingChunks.remove(pos);
    }

    @EventHandler
    private void onRender(Render3DEvent event) {
        if (!Utils.canUpdate() || matchingChunks.isEmpty()) return;

        SettingColor side = new SettingColor(sideColor.get());
        side.a = fillOpacity.get();
        SettingColor line = lineColor.get();

        int bottom = mc.field_1687.method_31607();
        int top = mc.field_1687.method_31600();

        for (class_1923 chunkPos : new HashSet<>(matchingChunks)) {
            double x1 = chunkPos.method_8326();
            double z1 = chunkPos.method_8328();
            double x2 = x1 + 16;
            double z2 = z1 + 16;

            event.renderer.box(x1, bottom, z1, x2, top, z2, side, line, shapeMode.get(), 0);
        }
    }

    @Override
    public String getInfoString() {
        return Integer.toString(matchingChunks.size());
    }

    private void scan() {
        if (!Utils.canUpdate() || mc.field_1724 == null) return;

        List<class_2248> targetBlocks = blocks.get();
        if (targetBlocks.isEmpty()) {
            matchingChunks.clear();
            return;
        }

        matchingChunks.clear();

        int viewDistance = mc.field_1690.method_38521();
        class_1923 playerChunk = mc.field_1724.method_31476();

        for (int cx = playerChunk.field_9181 - viewDistance; cx <= playerChunk.field_9181 + viewDistance; cx++) {
            for (int cz = playerChunk.field_9180 - viewDistance; cz <= playerChunk.field_9180 + viewDistance; cz++) {
                class_2818 chunk = mc.field_1687.method_8497(cx, cz);
                if (chunk == null || chunk.method_12223()) continue;

                if (chunkMatches(chunk)) {
                    matchingChunks.add(chunk.method_12004());
                }
            }
        }
    }

    private boolean chunkMatches(class_2818 chunk) {
        List<class_2248> targetBlocks = blocks.get();
        if (targetBlocks.isEmpty()) return false;

        int required = Math.min(requiredTypes.get(), targetBlocks.size());
        int found = 0;

        for (class_2248 block : targetBlocks) {
            if (!chunkContainsBlock(chunk, block)) continue;

            found++;
            if (found >= required) return true;
        }

        return false;
    }

    private boolean chunkContainsBlock(class_2818 chunk, class_2248 block) {
        for (class_2826 section : chunk.method_12006()) {
            if (section == null || section.method_38292()) continue;
            if (section.method_19523(state -> state.method_27852(block))) return true;
        }

        return false;
    }
}
