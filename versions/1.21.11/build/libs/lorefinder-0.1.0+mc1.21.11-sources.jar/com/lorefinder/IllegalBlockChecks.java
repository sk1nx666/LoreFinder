package com.lorefinder;

import net.minecraft.block.*;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2195;
import net.minecraft.class_2211;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2266;
import net.minecraft.class_2269;
import net.minecraft.class_2301;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2341;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_2356;
import net.minecraft.class_2399;
import net.minecraft.class_2401;
import net.minecraft.class_2404;
import net.minecraft.class_2420;
import net.minecraft.class_2421;
import net.minecraft.class_2472;
import net.minecraft.class_2473;
import net.minecraft.class_2523;
import net.minecraft.class_2527;
import net.minecraft.class_2537;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2742;
import net.minecraft.class_2756;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_3709;
import net.minecraft.class_3749;
import net.minecraft.class_4538;
import net.minecraft.class_5172;
import java.util.function.Predicate;

/**
 * Heuristics for block states / placements that cannot survive in vanilla.
 */
public final class IllegalBlockChecks {
    private IllegalBlockChecks() {}

    public static boolean isIllegal(
        class_4538 world,
        class_2338 pos,
        class_2680 state,
        boolean invalidPlacement,
        boolean floatingLava,
        boolean floatingWater,
        boolean orphanBeds,
        boolean orphanDoubleBlocks,
        boolean floatingAttached
    ) {
        if (state.method_26215()) return false;
        if (!isContextLoaded(world, pos)) return false;

        if (invalidPlacement && isInvalidPlacement(world, pos, state)) return true;
        if (floatingLava && isFloatingFluid(world, pos, state, true)) return true;
        if (floatingWater && isFloatingFluid(world, pos, state, false)) return true;
        if (orphanBeds && isOrphanBed(world, pos, state)) return true;
        if (orphanDoubleBlocks && isOrphanDoubleBlock(world, pos, state)) return true;
        if (floatingAttached && isFloatingAttachedBlock(world, pos, state)) return true;

        return false;
    }

    /** Fast section filter — skips empty-looking sections before per-block work. */
    public static boolean sectionMightContainIllegal(
        class_2826 section,
        boolean invalidPlacement,
        boolean floatingLava,
        boolean floatingWater,
        boolean orphanBeds,
        boolean orphanDoubleBlocks,
        boolean floatingAttached
    ) {
        if (section == null || section.method_38292()) return false;

        Predicate<class_2680> predicate = state -> {
            if (state.method_26215()) return false;
            class_2248 block = state.method_26204();

            if (floatingLava && (state.method_27852(class_2246.field_10164) || state.method_27852(class_2246.field_27098))) return true;
            if (floatingWater && (state.method_27852(class_2246.field_10382) || state.method_27852(class_2246.field_27097))) return true;
            if (orphanBeds && block instanceof class_2244) return true;
            if (orphanDoubleBlocks && state.method_28498(class_2741.field_12533)) return true;

            if (floatingAttached && isAttachedBlockType(block)) return true;

            if (invalidPlacement && mightBeInvalidPlacement(block, state)) return true;

            return false;
        };

        return section.method_19523(predicate);
    }

    private static boolean mightBeInvalidPlacement(class_2248 block, class_2680 state) {
        if (block instanceof class_2244 || block instanceof class_2404 || block instanceof class_2346) return false;
        if (state.method_28498(class_2741.field_12533)) return false;
        if (block instanceof class_2527 || block instanceof class_2341 || block instanceof class_2195) {
            return false;
        }
        if (block instanceof class_2261 && !(block instanceof class_2302) && !(block instanceof class_2473)) {
            return false;
        }

        return block instanceof class_2473
            || block instanceof class_2302
            || block instanceof class_2356
            || block instanceof class_2420
            || block instanceof class_2523
            || block instanceof class_2266
            || block instanceof class_2211
            || block instanceof class_2421
            || block instanceof class_2472
            || block instanceof class_2301;
    }

    private static boolean isAttachedBlockType(class_2248 block) {
        return block instanceof class_2527
            || block instanceof class_2341
            || block instanceof class_2269
            || block instanceof class_2401
            || block instanceof class_2399
            || block instanceof class_2537
            || block instanceof class_3709
            || block instanceof class_3749
            || block instanceof class_5172;
    }

    public static boolean isContextLoaded(class_4538 world, class_2338 pos) {
        if (!(world instanceof class_1937 w)) return false;
        if (!w.method_22340(pos)) return false;

        for (class_2350 direction : class_2350.values()) {
            if (!w.method_22340(pos.method_10093(direction))) return false;
        }

        return true;
    }

    /**
     * Neighbor chunks must be loaded and at {@link class_2806#field_12803} so placement checks
     * against blocks in adjacent chunks are not evaluated against stale or empty data.
     */
    public static boolean isChunkBorderContextLoaded(class_1937 world, class_1923 chunkPos) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (!world.method_8393(chunkPos.field_9181 + dx, chunkPos.field_9180 + dz)) return false;

                class_2818 chunk = world.method_8497(chunkPos.field_9181 + dx, chunkPos.field_9180 + dz);
                if (chunk == null || chunk.method_12223()) return false;
                if (!chunk.method_12009().method_12165(class_2806.field_12803)) return false;
            }
        }

        return true;
    }

    public static boolean isInvalidPlacement(class_4538 world, class_2338 pos, class_2680 state) {
        class_2248 block = state.method_26204();

        if (block instanceof class_2244 || block instanceof class_2404) return false;
        if (block instanceof class_2346) return false;
        if (state.method_28498(class_2741.field_12533)) return false;

        if (block instanceof class_2527 || block instanceof class_2341 || block instanceof class_2195) {
            return false;
        }

        if (block instanceof class_2261 && !(block instanceof class_2302) && !(block instanceof class_2473)) {
            return false;
        }

        return !state.method_26184(world, pos);
    }

    public static boolean isFloatingFluid(class_4538 world, class_2338 pos, class_2680 state, boolean lava) {
        if (lava) {
            if (!state.method_27852(class_2246.field_10164) && !state.method_27852(class_2246.field_27098)) return false;
        } else {
            if (!state.method_27852(class_2246.field_10382) && !state.method_27852(class_2246.field_27097)) return false;
        }

        class_2338 belowPos = pos.method_10074();
        class_2680 below = world.method_8320(belowPos);
        if (below.method_27852(class_2246.field_10164) || below.method_27852(class_2246.field_10382)) return false;

        return !below.method_26212(world, belowPos);
    }

    public static boolean isOrphanBed(class_4538 world, class_2338 pos, class_2680 state) {
        if (!(state.method_26204() instanceof class_2244)) return false;

        class_2742 part = state.method_11654(class_2244.field_9967);
        class_2350 facing = state.method_11654(class_2244.field_11177);
        class_2350 partnerDir = part == class_2742.field_12557 ? facing : facing.method_10153();
        class_2338 partnerPos = pos.method_10093(partnerDir);

        if (!(world instanceof class_1937 w) || !w.method_22340(partnerPos)) return false;

        class_2680 partner = world.method_8320(partnerPos);

        if (!(partner.method_26204() instanceof class_2244)) return true;

        class_2742 partnerPart = partner.method_11654(class_2244.field_9967);
        return partnerPart == part;
    }

    public static boolean isOrphanDoubleBlock(class_4538 world, class_2338 pos, class_2680 state) {
        if (!state.method_28498(class_2741.field_12533)) return false;

        class_2756 half = state.method_11654(class_2741.field_12533);
        class_2338 otherPos = half == class_2756.field_12609 ? pos.method_10074() : pos.method_10084();

        if (!(world instanceof class_1937 w) || !w.method_22340(otherPos)) return false;

        class_2680 other = world.method_8320(otherPos);

        if (!other.method_28498(class_2741.field_12533)) return true;

        class_2756 otherHalf = other.method_11654(class_2741.field_12533);
        return otherHalf == half;
    }

    public static boolean isFloatingAttachedBlock(class_4538 world, class_2338 pos, class_2680 state) {
        if (!isAttachedBlockType(state.method_26204())) return false;
        return !state.method_26184(world, pos);
    }
}
