package com.lorefinder;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_19;
import net.minecraft.class_1937;
import net.minecraft.class_22;
import net.minecraft.class_638;
import net.minecraft.class_9209;
import net.minecraft.class_9334;

/**
 * Resolves map IDs from client map states (authoritative for framed maps) and verified item stacks.
 */
public final class MapIdHelper {
    private static Method worldGetMapStates;
    private static Field mapStateFrames;

    private MapIdHelper() {}

    /**
     * Item frame entity ID → map ID from the client's loaded {@link class_22} frame markers.
     */
    public static Map<Integer, Integer> buildFrameEntityToMapId(class_1937 world) {
        Map<class_9209, class_22> states = getClientMapStates(world);
        if (states == null || states.isEmpty()) return Collections.emptyMap();

        Map<Integer, Integer> entityToMapId = new HashMap<>();

        for (Map.Entry<class_9209, class_22> entry : states.entrySet()) {
            int mapId = entry.getKey().comp_2315();
            Map<String, class_19> frames = getMapStateFrames(entry.getValue());
            if (frames == null) continue;

            for (class_19 marker : frames.values()) {
                entityToMapId.put(marker.comp_3493(), mapId);
            }
        }

        return entityToMapId;
    }

    public static Integer resolveMapId(class_1799 stack, class_1533 frame, class_1937 world, Map<Integer, Integer> frameIndex) {
        if (world == null) return null;

        if (frame != null && frameIndex != null) {
            Integer fromState = frameIndex.get(frame.method_5628());
            if (fromState != null) return fromState;
        }

        return getVerifiedStackMapId(stack, world);
    }

    public static Integer getVerifiedStackMapId(class_1799 stack, class_1937 world) {
        if (stack == null || stack.method_7960() || !stack.method_31574(class_1802.field_8204)) return null;
        if (!stack.method_57353().method_57832(class_9334.field_49646)) return null;

        class_9209 component = stack.method_58694(class_9334.field_49646);
        if (component == null) return null;

        int id = component.comp_2315();
        if (id <= 0) return null;
        if (class_1806.method_7997(component, world) == null) return null;

        return id;
    }

    public static boolean isOldMap(int mapId, int minIdInclusive, int maxIdExclusive) {
        return mapId >= minIdInclusive && mapId < maxIdExclusive;
    }

    @SuppressWarnings("unchecked")
    private static Map<class_9209, class_22> getClientMapStates(class_1937 world) {
        if (!(world instanceof class_638)) return null;

        try {
            if (worldGetMapStates == null) {
                worldGetMapStates = class_1937.class.getDeclaredMethod("getMapStates");
                worldGetMapStates.setAccessible(true);
            }

            Object result = worldGetMapStates.invoke(world);
            if (result instanceof Map<?, ?> map) {
                return (Map<class_9209, class_22>) map;
            }
        } catch (ReflectiveOperationException ignored) {
        }

        return null;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, class_19> getMapStateFrames(class_22 state) {
        if (state == null) return null;

        try {
            if (mapStateFrames == null) {
                mapStateFrames = class_22.class.getDeclaredField("frames");
                mapStateFrames.setAccessible(true);
            }

            Object result = mapStateFrames.get(state);
            if (result instanceof Map<?, ?> map) {
                return (Map<String, class_19>) map;
            }
        } catch (ReflectiveOperationException ignored) {
        }

        return null;
    }
}
